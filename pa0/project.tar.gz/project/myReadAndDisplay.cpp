/*	name: cong qiu
 *	email: congq@g.clemson.edu
 *  date: 7th Sep 2015
 *
 */


#include<OpenImageIO/imageio.h>
OIIO_NAMESPACE_USING

#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

#include<stdlib.h>
#include<string>
#include<algorithm>
#include<iostream>
#include<vector>
using std::vector;

//data to be displayed
GLubyte* big_chunk_of_data;
//data to be output to file
GLubyte* outputfile;


char* outputfilename;
char * inputFilename;
int do_output = 0;
char outputcolor;

//information of images
int imageWidth= 0;
int imageHeight= 0;
int chanls = 0;
vector<vector<vector<GLubyte> > > data;


//flip the displaying data
void flip(){
		GLbyte tmp;
		for(int y = 0;y != imageHeight/2; y++){
				for(int x =0; x != imageWidth; x++){
						for(int c = 0; c!= chanls ;c++){
								tmp = big_chunk_of_data[c+ x*chanls + y*imageWidth*chanls];
								big_chunk_of_data[c + x*chanls+ y*imageWidth*chanls] = big_chunk_of_data[c + x * chanls + (imageHeight-1-y)* imageWidth * chanls];
								big_chunk_of_data[c + x * chanls + (imageHeight-1-y)* imageWidth * chanls] = tmp;
						}
				}
		}
}


void init(void)
{
		glClearColor(0.0, 0.0, 0.0, 0.0);
		glShadeModel(GL_FLAT);
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
}


void display(void)
{
		flip();
		glClear(GL_COLOR_BUFFER_BIT);
		if(chanls ==3)
				glDrawPixels(imageWidth, imageHeight, GL_RGB, GL_UNSIGNED_BYTE, big_chunk_of_data);
		else 

				glDrawPixels(imageWidth, imageHeight, GL_RGBA, GL_UNSIGNED_BYTE, big_chunk_of_data);
		glFlush();
}

//output data to display
void dis(){
		for(int y=0; y != imageHeight; y ++){
				for(int x = 0;x != imageWidth; x ++){
						for(int c = 0;c != chanls ; c++)
						{
								big_chunk_of_data[c + x* chanls+ y * imageWidth* chanls]=data[y][x][c];
						}
				}
		}
}


void write_to_file(){
		outputfile = new GLubyte[imageHeight* imageWidth*chanls];

		for(int y=0; y != imageHeight; y ++){
				for(int x = 0;x != imageWidth; x ++){
						for(int c = 0;c != chanls ; c++)
						{
								outputfile[c + x* chanls+ y * imageWidth* chanls]=data[y][x][c];
						}
				}
		}

		ImageOutput *out = ImageOutput::create(outputfilename);

		ImageSpec spec (imageWidth, imageHeight, chanls, TypeDesc::UINT8);
		out->open(outputfilename, spec);
		out->write_image(TypeDesc::UINT8, outputfile);
		out->close();

};

void handleKey(unsigned char key,int x, int y){
		switch (key){
				case 'f':
						std::reverse(data.begin(), data.end());
						dis();
						break;	
				case 'i':
						for(int y=0; y != imageHeight; y ++){
								std::reverse(data[y].begin(), data[y].end());
						}
						dis();	
						break;
				case 'r':
				case 'g':
				case 'b':{
								 int pos=0;
								 if(key=='g') pos = 1;
								 if(key == 'b') pos =2;
								 for(int i = 0; i != imageHeight * imageWidth*chanls;i++){
										 if(i%chanls!=pos)
												 big_chunk_of_data[i] = 0;
								 }
								 break;
						 }
				case 'o':
						 dis();
						 break;

				case 'w':
						 if (do_output==1){
								 write_to_file();
						 }
						 dis();
				default:

						 break;
		}
		glutPostRedisplay();
}


void readfile(){

		ImageInput *in = ImageInput::open(inputFilename);

		if(!in){
				std::cout << "file not exist" << std::endl;
				exit(-1);
		}


		const ImageSpec & spec = in->spec();
		imageWidth = spec.width;
		imageHeight = spec.height;
		chanls = spec.nchannels;

		big_chunk_of_data = new GLubyte[imageHeight*imageWidth*chanls];

		if(!in->read_image(TypeDesc::UINT8 , big_chunk_of_data)){
				std::cout << "cant read data" << std::endl;
				delete in;

				exit(-1);
		}
		flip();
		//store data in data vector;
		for(int y = 0; y != imageHeight; y ++){
				vector<vector<GLubyte> > line;
				for(int x = 0; x != imageWidth; x ++){
						vector<GLubyte> pixel;
						for(int c = 0; c != chanls; c ++){
								pixel.push_back(big_chunk_of_data[c + x*chanls + y * imageWidth*chanls]);
						}
						line.push_back(pixel);
				}
				data.push_back(line);
		}
}


int main(int argc, char** argv){
		if(argc< 2){
				std::cerr<< "Usage: " << argv[0] << "[filename]" << std::endl;
				exit(-1);
		}
		inputFilename= argv[1];
		readfile();
		if(argc>2){
				do_output = 1;
				outputfilename = argv[2];
		}
		
		glutInit(&argc, argv);
		glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
		glutInitWindowSize(imageWidth, imageHeight);
		glutInitWindowPosition(0, 0);
		glutCreateWindow(argv[0]);
		init();
		glutDisplayFunc(display);
		glutKeyboardFunc(handleKey);
		glutMainLoop();
		return 0;
}

